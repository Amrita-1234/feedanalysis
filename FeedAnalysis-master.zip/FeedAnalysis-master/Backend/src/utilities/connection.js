const mongoose=require('mongoose');
const Schema=mongoose.Schema;
const uniqueValidator=require('mongoose-unique-validator');
mongoose.set('useCreateIndex', true)
const url = "mongodb://localhost:27017/FeedAnalysis_DB";
//Mongoose.set('useCreateIndex', true)
let collections=[];

let userRegisterSchema=new Schema(
    {
        educatorId:{
            type:String,
            
        },
    firstName:{
        type:String,
       
    },
    lastName:{
        type:String,
        
    },
    email:{
        type:String,
        
        
    },
    dept:{
        type:String,
    },
    password:{
        type:String,
        
    }
},{
        collection:'register',
    }
   
);
let batchDetailSchema=new Schema(
    {
        batch:String,
        educatorId:String,
        course:String
    },{
        collection:'Batch',
    }
);
let trackLeadSchema=new Schema(
    {
        Name:String,
        trackLeadEmailId:String,
        password:String
    },{
        collection:'TrackLead',
    }
);
let classFeedBackSchema=new Schema(
    {
        educatorId:String,
        batch:String,
        rating1:Number,
        rating2:Number,
        rating3:Number,
        text:String,
        negative:Number,
        neutal:Number,
        positive:Number,
        compound:Number
    },{
        collection:'class',
    }
);
let courseFeedBackSchema=new Schema(
    {
        educatorId:String,
        course:String,
        rating1:Number,
        rating2:Number,
        rating3:Number,
        text:String,
        negative:Number,
        neutal:Number,
        positive:Number,
        compound:Number
        
    },{
        collection:'course',
    }
);
let NotificationSchema=new Schema(
    {
        from:String,
        Date:Date,
        Text:String,
        to:String
        
    },{
        collection:'Notification',
    }
);
//userSchema.plugin(uniqueValidator,{message:'Email already in use!'})
collections.getRegisterCollection=()=>{
    return mongoose.model('Register',userRegisterSchema);
    
}
collections.getClassFeedBackCollection=()=>{
    return mongoose.model('Class',classFeedBackSchema);
    
}
collections.getCourseFeedBackCollection=()=>{
    return mongoose.model('Course',courseFeedBackSchema);
    
}
collections.getNotificationCollection=()=>{
    return mongoose.model('Notification',NotificationSchema);
    
}
collections.getTrackLeadCollection=()=>{   
    return mongoose.connect(url, { useNewUrlParser: true,
        useUnifiedTopology: true}).then((database) => {
        console.log('Successfully connected to MongoDB');
    return database.model('TrackLead',trackLeadSchema);
}).catch((error) => {
    let err = new Error("Could not connect to Database");
    err.status = 500;
    throw err;
})
}
collections.getBatchCollection=()=>{   
    return mongoose.connect(url, { useNewUrlParser: true,
        useUnifiedTopology: true}).then((database) => {
        console.log('Successfully connected to MongoDB');
    return database.model('Batch',batchDetailSchema);
}).catch((error) => {
    let err = new Error("Could not connect to Database");
    err.status = 500;
    throw err;
})
}

module.exports=collections;





