const collection = require('../utilities/connection');
const batchDb = [
    {
        batch: "INTERNBATCH-February",
        educatorId: "568697",
        course: "JAVA"
    },
    {
        batch: "INTERNBATCH-January",
        educatorId: "568680",
        course: "JAVA"
    }

]
exports.setupDb = () => {
    return collection.getBatchCollection().then((batch) => {
        return batch.deleteMany().then(() => {
           return  batch.insertMany(batchDb).then((data) => {
                if (data) return "Batch Details is Successfully Inserted"
                else {
                    let err = new Error("Insertion failed");
                    err.status = 400;
                    throw err;
                }
            })
        })
    })
}
