const express = require('express');
const routing = express.Router();
const mongoose=require('mongoose');
const create = require('../model/dbsetup');
const trackleadDB=require('../model/TrackLead');
const vader=require('vader-sentiment');
const nodemailer=require('nodemailer');
const twilio=require('twilio');

const collection=require('../utilities/connection');
const Notify=collection.getNotificationCollection();
const Educator=collection.getRegisterCollection();
const Batch=collection.getBatchCollection();
const tracklead=collection.getTrackLeadCollection();
const Class=collection.getClassFeedBackCollection();
const Course=collection.getCourseFeedBackCollection();
//routes
routing.get('/setupDb', (req, res, next) => {
    create.setupDb().then((data) => {
        res.send(data)
    }).catch((err) => {
        next(err)
    })
})
routing.get('/trackleadDb', (req, res, next) => {
    trackleadDB.TrackLeadDb().then((data) => {
        res.send(data)
    }).catch((err) => {
        next(err)
    })
})
routing.get('/getTrackLead', (req, res, next) => {
    collection.getTrackLeadCollection().then((ele) => {
        ele.find().then((data) => {
           res.json(data);
       
       }).catch(err => next(err));
   }).catch(err => next(err));
})
routing.get('/notification',(req,res,next)=>{
    Notify.find().exec().then(result=>{
        console.log(result);
        res.json(result)
    })
    .catch(err=>{
        next(err);
    })
})
routing.get('/getBatchDetails', (req, res, next) => {
     collection.getBatchCollection().then((batch) => {
         batch.find().then((data) => {
            res.json(data);
        
        }).catch(err => next(err));
    }).catch(err => next(err));
})

routing.get('/',(req,res,next)=>{
    Educator.find().exec().then(result=>{
            console.log(result);
            res.json(result)
        })
        .catch(err=>{
            next(err);
        })
    })

routing.get('/login',(req,res,next)=>{
    Educator.find().exec().then(result=>{
        console.log(result);
        res.json(result);
    })
    .catch(err=>{
        next(err);
    })
})
routing.get('/getCourseFeedBack',(req,res,next)=>{
    Course.find().exec().then(result=>{
        console.log(result);
        res.json(result);
    })
    .catch(err=>{
        next(err);
    })
})
routing.get('/getClassFeedBack',(req,res,next)=>{
    Class.find().exec().then(result=>{
        console.log(result);
        res.json(result);
    })
    .catch(err=>{
        next(err);
    })
})
routing.post('/register',(req,res,next)=>{
    console.log(req.body.educatorId);
    console.log(req.body.firstName);
    console.log(req.body.lastName);
    console.log(req.body.email);
    console.log(req.body.dept);
    console.log(req.body.password);
    var register=new Educator({
    educatorId:req.body.educatorId,
    firstName:req.body.firstName,
    lastName:req.body.lastName,
    email:req.body.email,
    dept:req.body.dept,
    password:req.body.password

});

register.save()
.then(result=>{
    console.log(result);
    //res.json({msg:'Successfully submitted'})
    //res.send(result)
    
}).catch(err=>{
    console.log(err);
    next(err);
    //res.json({msg:'error occurred'})
})
    res.send('Successfully stored in database');
})

routing.post('/classFeedBack',(req,res,next)=>{
    console.log(req.body.educatorId);
    console.log(req.body.batch);
    console.log(req.body.rating1);
    console.log(req.body.rating2);
    console.log(req.body.rating3);
    console.log(req.body.text);
    const input=req.body.text;
    const classIntensity=vader.SentimentIntensityAnalyzer.polarity_scores(input);
    console.log(classIntensity);
    console.log(classIntensity['neg'])
    console.log(classIntensity['neu'])
    console.log(classIntensity['pos'])
    console.log(classIntensity['compound'])
    
    Class.updateOne({
    educatorId:req.body.educatorId,
    batch:req.body.batch
},{$set:{
    educatorId:req.body.educatorId,
    batch:req.body.batch,
    rating1:req.body.rating1,
    rating2:req.body.rating2,
    rating3:req.body.rating3,
    text:req.body.text,
    negative:classIntensity['neg'],
    neutal:classIntensity['neu'],
    positive:classIntensity['pos'],
    compound:classIntensity['compound']
}},{upsert: true }).then(result=>{
    console.log("updated");
    //res.json({msg:'Successfully submitted'})
    //res.send(result)
    
}).catch(err=>{
    console.log("cant update class");
    next(err);
})
 //res.json({msg:'error occurred'})

    res.send('Successfully stored in database');
})
routing.post('/courseFeedBack',(req,res,next)=>{
    console.log(req.body.educatorId);
    console.log(req.body.course);
    console.log(req.body.rating1);
    console.log(req.body.rating2);
    console.log(req.body.rating3);
    console.log(req.body.text);
    const input1=req.body.text;
    const courseIntensity=vader.SentimentIntensityAnalyzer.polarity_scores(input1);
    console.log(courseIntensity);
    console.log(courseIntensity['neg'])
    console.log(courseIntensity['neu'])
    console.log(courseIntensity['pos'])
    console.log(courseIntensity['compound'])
    
     Course.updateOne({
    educatorId:req.body.educatorId,
    course:req.body.course,
     },{$set:{educatorId:req.body.educatorId,
        course:req.body.course,
        rating1:req.body.rating1,
        rating2:req.body.rating2,
        rating3:req.body.rating3,
        text:req.body.text,
        negative:courseIntensity['neg'],
        neutal:courseIntensity['neu'],
        positive:courseIntensity['pos'],
        compound:courseIntensity['compound']
    }},{upsert:true})

.then(result=>{
    console.log(result);
    //res.json({msg:'Successfully submitted'})
    //res.send(result)
    
}).catch(err=>{
    console.log(err);
    next(err);
    //res.json({msg:'error occurred'})
})
    res.send('Successfully stored in database');
})
routing.post('/notification',(req,res,next)=>{
    console.log(req.body.from);
    console.log(req.body.Date);
    console.log(req.body.Text);
    console.log(req.body.to);
    
    var not=new Notify({
    from:req.body.from,
    Date:req.body.Date,
    Text:req.body.Text,
    to:req.body.to
    

});

not.save()
.then(result=>{
    console.log(result);
    //res.json({msg:'Successfully submitted'})
    //res.send(result)
    
}).catch(err=>{
    console.log(err);
    next(err);
    //res.json({msg:'error occurred'})
})
    res.send('Successfully stored in database');
})


routing.get("/sendsms",(req,res)=>{
var client=new twilio('AC5d84f098a73f2f745668d0c61db94a95','ccd226e6748681a0b3688b7edbd893cb')
client.messages.create({
    to:'+91 6302677128',
    from:'+91 9304196131',
    body:'hello from twilio!',
}).then(()=>res.send("SMS sent!S"))

})
/*
let transporter=nodemailer.createTransport({
    //host:'mail.ad.infosys.com',
    service:'Gmail',
    //port:587,
    //secure:false,
    //service:'false',
    auth:{
        user:'movvasandeep11@gmail.com',
        pass:'9052143411'
    },
    tls:{
        rejectUnauthorized:false
    }
});
//setup email
let mailOptions={
    from:'"Nodemailer Contact" <movvasandeep11@gmail.com>',//sender address
    to:'sandeep20.trn@infosys.com',// list of receivers
    subject:'Node Contact Request',
    text:'Hello world?',
    html:'project work'
};
transporter.sendMail(mailOptions,(error,info)=>{
    if(error){
        console.log(error);
    }
    else{
console.log("Email sent successfully:"+info.response);
    }
    //console.log('Message sent:%s',info.messageId);
    //console.log('Preview URL:%s',nodemailer.getTestMessageUrl(info));
});
*/
module.exports = routing;
