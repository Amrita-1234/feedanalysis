import React, { Component } from "react";
import axios from "axios";
import Login from './login';
import { Redirect,Link} from "react-router-dom";

import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";


const driver1 = ()=>{
    let x = document.querySelector(".nav-links");
    x.style.right = "-200px";
}


const driver2 = ()=>{
    var x = document.querySelector(".nav-links");
    x.style.right = "0";
}




const url = "http://localhost:1050/register/";

const emailRegex = RegExp(
  /^[a-zA-Z0-9.!#$%&'*+/=?^_{|}~-]+@(infosys)+.(com)*$/
);
const educatorIdRegex=RegExp(
/^[1-9]{1}[0-9]{5}$/
);
const passw=RegExp(
  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,15}$/
  );

class Register extends Component {
  constructor(props) {
    super(props);
    this.state = {
      form: {
        educatorId: null,
        firstName: null,
        lastName: null,
        email: null,
        dept:null,
        password: null,
        confirmpassword:null
      },
      formErrors: {
        educatorId: "",
        firstName: "",
        lastName: "",
        email: "",
        dept:"",
        password: "",
        confirmpassword:""
      },
      formValid:{
        educatorId: false,
        firstName: false,
        lastName: false,
        email: false,
        dept:false,
        password: false,
        confirmpassword:false,
        buttonActive:false
      },
      updateStatus:false,
      errorMessage:"",
      successMessage:""
    }
  };
  submitregister = () => {
    const { form,formErrors } = this.state;
    
    axios.post(url, {
      educatorId: form.educatorId,
        firstName:form.firstName,
        lastName: form.lastName,
        email: form.email,
        dept:form.dept,
        password: form.password
    })
      .then(res => {
        this.setState({updateStatus:true})
        console.log(res.data.form);
      }).catch(error => {
        console.log("error in submitting data");
      });
  };
  
  handleSubmit = event => {
    event.preventDefault();
      
      console.log(`
      ---SUBMITTING---
      Educator Id:${this.state.form.educatorId}
      First Name:${this.state.form.firstName}
      Last Name:${this.state.form.lastName}
      Email:${this.state.form.email}
      Department:${this.state.form.dept},
      Password:${this.state.form.password},
      confirmpassword:${this.state.form.confirmpassword}
      `)
      if(this.state.form.password===this.state.form.confirmpassword)
      {
        this.submitregister();
      }else{
        console.log("confirmpassword not matched with password");
      }

  };

  handleChange = event => {
    const target = event.target;
    const value=target.value;
    const name=target.name;
    
    const {form}=this.state
    this.setState({form:{...form,[name]:value}})
    this.validateField(name, value);
  };

  validateField = (name, value) => {
    let fieldValidationErrors = this.state.formErrors;
    let formValid = this.state.formValid;
    switch (name) {
      case "educatorId":
        if(value===''){
          fieldValidationErrors.educatorId='field required'
          formValid.educatorId = false;
        }else if(educatorIdRegex.test(value)){
          fieldValidationErrors.educatorId='';
          formValid.educatorId = true;
        }else{
          fieldValidationErrors.educatorId='minimum 6 digits required';
          formValid.educatorId = false;
        }
        break;
      case "firstName":
        if(value===""){
          fieldValidationErrors.firstName='field required'
          formValid.firstName = false;
        }else if(value.length<3){
          fieldValidationErrors.firstName='minimum 3 characters required';
          formValid.firstName = false;
        }else{
          fieldValidationErrors.firstName=''
          formValid.firstName = true;
        }
        break;
      case "lastName":
        if(value===""){
          fieldValidationErrors.lastName='field required'
          formValid.lastName = false;
        }else if(value.lenght<3){
          fieldValidationErrors.lastName='minimum 3 characters required'
          formValid.lastName = false;
        }else{
          fieldValidationErrors.lastName=''
          formValid.lastName = true;
        }
        break;
      case "email":
        if(value===""){
          fieldValidationErrors.email="field required"
          formValid.email = false;
        }else if(emailRegex.test(value)){
          fieldValidationErrors.email=""
          formValid.email = true;
        }else{
          fieldValidationErrors.email='Invalid email address'
          formValid.email = false;
        }
        

        break;
        case "dept":
          if(value===""){
            fieldValidationErrors.dept="field required"
            formValid.dept = false;
          }else if(value.length<3){
            fieldValidationErrors.dept="minimum 3 csharacters required"
            formValid.dept = false;
          }else{
            fieldValidationErrors.dept=''
            formValid.dept = true;
          }
         
  
          break;
          case "password":
            if(value===""){
              fieldValidationErrors.password="field required"
              formValid.password = false;
            }else if(passw.test(value)){
              fieldValidationErrors.password=""
              formValid.password = true;
            }else{
              fieldValidationErrors.password="contains atleast 1 character,1 special character ,1 digit"
              formValid.password = false;
            }
            this.setState({ formErrors:fieldValidationErrors})
        break;
        case "confirmpassword":
          if(value===""){
            fieldValidationErrors.confirmpassword="field required"
            formValid.confirmpassword = false;
          }
          else if(passw.test(value)){
            fieldValidationErrors.confirmpassword=""
            formValid.confirmpassword = true;
          }
          else 
          {
            fieldValidationErrors.confirmpassword="contains atleast 1 character,1 special character ,1 digit"
            formValid.confirmpassword = false;
          }
          
        break;
      default:
        break;
    }
    formValid.buttonActive=formValid.educatorId &&formValid.firstName&&formValid.lastName
     &&formValid.email&&formValid.dept&&formValid.password&& formValid.confirmpassword
    this.setState({ formErrors:fieldValidationErrors,  formValid:formValid,successMessage:""})
    
  };
  render() {

    const { formErrors } = this.state
    var redirect=null;
    if(this.state.updateStatus ===true){
      console.log("successfully submitted the data into database");
     redirect=<Redirect to={"/login"} ></Redirect>
    }
    return (
      <div className="header">
            <nav>
                <div className="nav-links">
                <FontAwesomeIcon icon = "greater-than" className = "fa1" onClick = {driver1}/>
                <ul>
                    
                    <li><Link to = "/homepage">Home</Link></li>
                    <li><Link to = "/login">Login</Link></li>
                    <li><Link to = "/about">About</Link></li>
                    
                </ul>
                </div>
                <FontAwesomeIcon icon = "bars" className = "fa1" onClick = {driver2} />
            </nav>

      <div className='wrapper'>
        <div className='form-wrapper'>
          <h1> Create Account</h1>
          <form onSubmit={this.handleSubmit}>

            <div className="firstName">
              <label htmlFor="firstName">First Name </label>
              <input
                className={formErrors.firstName.length > 0 ? "error" : null}
                type="text"
                name="firstName"
                id="firstName"
                value={this.state.form.firstName}
                placeholder="firstname "

                onChange={this.handleChange}

              />
              {
                formErrors.firstName.length > 0 && (
                  <span className="text-danger">{formErrors.firstName}</span>
                )
              }
            </div>
            <div className="lastName">
              <label htmlFor="lastName">Last Name </label>
              <input
                type="text"
                className={formErrors.lastName.length > 0 ? "error" : null}
                name="lastName"
                id="lastName"
                value={this.state.form.lastName}
                placeholder="lastname "

                onChange={this.handleChange}

              />
              {
                formErrors.lastName.length > 0 && (
                  <span className="text-danger">{formErrors.lastName}</span>
                )
              }
            </div>
            <div className="educatorId">
              <label htmlFor="educatorId">Educator Id </label>
              <input
                className={formErrors.educatorId.length > 0 ? "error" : null}
                type="text"
                name="educatorId"
                id="educatorId"
                value={this.state.form.educatorId}
                placeholder="Id number"

                onChange={this.handleChange}
                
              />
              {
                formErrors.educatorId.length > 0 && (
                  <span className="text-danger">{formErrors.educatorId}</span>
                )
              }
            </div>
            <div className="email">
              <label htmlFor="email">Email </label>
              <input
                className={formErrors.email.length > 0 ? "error" : null}
                type="text"
                name="email"
                id="email"
                placeholder="email "
                value={this.state.form.email}
                onChange={this.handleChange}

              />
              {
                formErrors.email.length > 0 && (
                  <span className="text-danger">{formErrors.email}</span>
                )
              }
            </div>
            <div className="dept">
              <label htmlFor="dept">Department </label>
              <input
                className={formErrors.email.length > 0 ? "error" : null}
                type="text"
                name="dept"
                id="dept"
                placeholder="dept "
                value={this.state.form.dept}
                onChange={this.handleChange}

              />
              {
                formErrors.dept.length > 0 && (
                  <span className="text-danger">{formErrors.dept}</span>
                )
              }
            </div>
            <div className="password">
              <label htmlFor="password">password </label>
              <input
                className={formErrors.password.length > 0 ? "error" : null}
                type="password"
                name="password"
                id="password"
                placeholder="password "
                value={this.state.form.password}
                onChange={this.handleChange}

              />
              {
                formErrors.password.length > 0 && (
                  <span className="text-danger">{formErrors.password}</span>
                )
              }
            </div>
            <div className="confirmpassword">
              <label htmlFor="confirmpassword">Confirm Password </label>
              <input
                className={formErrors.confirmpassword.length > 0 ? "error" : null}
                type="password"
                name="confirmpassword"
                id="confirmpassword"
                placeholder="confirmpassword "
                value={this.state.form.confirmpassword}
                onChange={this.handleChange}

              />
              {
                formErrors.confirmpassword.length > 0 && (
                  <span className="text-danger">{formErrors.confirmpassword}</span>
                )
              }
            </div>
            <div className="createAccount">
            <button type="submit" className="btn btn-primary" disabled={!this.state.formValid.buttonActive} 
             >Create Account</button>
              
            </div>
            
          </form>
          <br />
        </div>
        {redirect}
      </div>
        </div>
    );
  }
}

export default Register;