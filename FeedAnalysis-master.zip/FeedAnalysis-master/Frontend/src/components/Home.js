import React, { useState, useEffect,useRef } from 'react';
import { BrowserRouter as Router, useParams, Link, Switch, Route, Redirect, useHistory } from "react-router-dom";
import axios from "axios";
import {Dropdown,DropdownToggle,Button, ButtonGroup} from 'react-bootstrap'
import {makeStyles} from '@material-ui/core/styles';
import Badge from '@material-ui/core/Badge';
import MailIcon from '@material-ui/icons/NotificationsActiveRounded';
import "./styles.css"
import {useDetectOutsideClick} from "./useDetectOutsideClick";
import {NotificationManager} from "react-notifications";
import { useMemo } from 'react';
import { List } from '@material-ui/core';
const Home = () => {
  const { id,dept } = useParams();
  const dropdownRef=useRef(null);
const [isActive, setIsActive]=useDetectOutsideClick(dropdownRef,false);
const onClick=()=>setIsActive(!isActive);
  let[department,setDepartment]=useState(null);
  let [responseData, setResponseData] = useState([]);
  let count=0;
  let [responseNotifyData, setResponseNotifyData] = useState([]);
  useEffect(() => {
    axios.get('http://localhost:1050/').then((res) => {
      console.log(res.data)
      setResponseData(res.data)
      noteRegister();
responseNotifyData.map((item)=>{
  if(item.to===id)
  {
    count=count+1;
  }
})
    }).catch((err) => {
      console.log(err)
    })
  }, [])
  const noteRegister=()=>{
    axios.get('http://localhost:1050/notification').then((response) => {
      console.log(response.data)
      setResponseNotifyData(response.data)
    }).catch((err) => {
      console.log(err)
    })
  }
const useStyles=makeStyles((theme)=>({
  root:{
    '& > *':{
      margin:theme.spacing(1)
    },
  },
}));
  const history = useHistory();
  function logout() {
    localStorage.clear();
    history.push('/');
  }
  function pass(){
    history.push("/batchDetails/" + id+"/"+dept)
  }

  return (
    <div className="header3">
      
      <nav>
        <div className="nav-links">
        <ul>
            <li>
            <Dropdown as={ButtonGroup}>
          <Dropdown.Toggle split variant="success" id="dropdown-split-basic">
                <Badge badgeContent={count} color="primary"  ><MailIcon  />
            </Badge>
                </Dropdown.Toggle>
                <Dropdown.Menu display="inline">
                {
            responseNotifyData.map((data) => data.to=== id ?
            <Dropdown.Item key={data.educatorId}>{data.Text}</Dropdown.Item> : ""
            )
          }
          
          
                  
                </Dropdown.Menu>
              </Dropdown>
               
            </li>
            <li></li>
          <li><Link onClick={logout}>Logout</Link></li>
          </ul>
        </div>
      </nav>
      <div className="text-box">
        <h1>
          {
            responseData.map((data) => data.educatorId === id ?
              <h5 key={data.educatorId}>Welcome {data.firstName}
            </h5> : ""
            )
          }
        </h1>
        </div>
       
        <nav>
        <div className="nav-links">
          <ul>
          <li><Link onClick={pass}>Details</Link></li>
          </ul>
        </div>
      </nav>
        <div style={{flex:1,justifyContent:'flex-end'}}>
          
        </div>
        
          </div >
  );
};

export default Home
