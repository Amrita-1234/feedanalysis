import React from 'react';
import {BrowserRouter as Router, Link, Switch, Route, Redirect, useHistory} from "react-router-dom";

import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";


const driver1 = ()=>{
    let x = document.querySelector(".nav-links");
    x.style.right = "-200px";
}


const driver2 = ()=>{
    var x = document.querySelector(".nav-links");
    x.style.right = "0";
}



const Homepage= () => {
    return (
        <>
        <div className="header-ptr">
            <nav>
                <div className="pptx">
                    <h3>Track Lead</h3>
                </div>
                <div className="nav-links">
                <FontAwesomeIcon icon = "greater-than" className = "fa1" onClick = {driver1}/>
                <ul>
                    
                    <li><Link to = "/login">Login</Link></li>
                    <li><Link to = "/register">Sign up</Link></li>
                    <li><Link to = "/about2">About Us</Link></li>
                    <li><Link to = "/homepage">Educator → </Link></li>
                </ul>
                </div>

                <FontAwesomeIcon icon = "bars" className = "fa1" onClick = {driver2} />
            </nav>
            <div className="text-box">
            <h1>The whole purpose of education is to turn mirrors into windows.</h1>
            
            </div>
        
        </div>

        <section className = "ccse">
            <h1>Build and Developed By</h1>
            <p>Infosys Technologies Pvt. Ltd</p>

            <div className="row-px">
                <div className="ccse-col">
                    <h3>Sandeep</h3>
                    <p><ul><li>+91 9052143411</li> <li>sandeep@infosys.com</li> <li>Andra Pradesh, India</li></ul></p>
                </div>

                <div className="ccse-col">
                    <h3>Aman</h3>
                    <p><ul><li>+91 9304196131</li> <li>aman@infosys.com</li> <li>Jharkhand, India</li></ul></p>
                </div>

                <div className="ccse-col">
                    <h3>Arijit</h3>
                    <p><ul><li>+91 9477507092</li> <li>arijit@infosys.com</li><li>West Bengal, India</li></ul></p>
                </div>
                
                
            </div>

            <div className="row-px">
            <div className="ccse-col">
                    <h3>Akshitha</h3>
                    <p><ul><li>+91 7013329556</li> <li>akshitha@infosys.com</li><li>Andra Pradesh, India</li></ul></p>
                </div>

                <div className="ccse-col">
                    <h3>Amrita</h3>
                    <p><ul><li>+91 8637584407</li> <li>amrita@infosys.com</li><li>West Bengal, India</li></ul></p>
                </div>

            </div>
        </section>
        

        </>

    );
};

export default Homepage;
