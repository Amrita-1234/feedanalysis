import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, useParams, Link, Switch, Route, Redirect, useHistory } from "react-router-dom";
import axios from "axios";
import { Pie, Doughnut,defaults ,Bar} from 'react-chartjs-2';
//defaults.global.tooltips.enabled=false
//defaults.global.legend.position='bottom'
const ClassReport = (props) => {
    let { id,dept, batch} = useParams();
    console.log(id);
    console.log(batch);
    let [responseData, setResponseData] = useState([]);
    var data1=[]
    var data=responseData.map(function(e){
        if(e.educatorId===id && e.batch===batch)
        {
        data1.push(e.rating1);
        data1.push(e.rating2);
        data1.push(e.rating3)
        data1.push(e.negative*5)
        data1.push(e.neutal*5)
        data1.push(e.positive*5)
        
        }else{
            console.log("No data found")
        }
        return e.rating1+e.rating2;
    });;
    console.log(data1)
    let labels=[]
    useEffect(() => {
        axios.get('http://localhost:1050/getClassFeedBack').then((res) => {
            console.log(res.data)
            
            setResponseData(res.data)
           
            
        }).catch((err) => {
            console.log(err)
        })
    }, [])
    let status={
        labels:['Attendance','Behaviour','Punctuality','negative','neutal','positive'],
        datasets:[
            {
            label:'Rainfall',
           backgroundColor:[
            '#B21F00',
               '#C9DE00',
               '#2FDE00',
               '#00A6B4',
               '#6800B4',
               'Black'
               

           ],
           hoverBackgroundColor:[
            '#501800',
            '#4B5000',
            '#175000',
            '#003350',
            '#35014F'
               
           ],
            data:data1
            }
        ]
    }
            return(
                <div className="header3">
    <nav>
    <div className="nav-links2">
        <ul>
        <li><Link to={"/home/"+id+"/"+dept}>Home</Link></li>
        
        </ul>
      </div>
      <div className="nav-links3">
        <ul>
            
        <li>Class Report</li>
        <li></li>
        <li></li>
        </ul>
        
      </div>
      <div className="nav-links">
        <ul>
        <li><Link to={"/class/"+id+"/"+dept+"/"+batch}>Back</Link></li>
        </ul>
      </div>
      
    </nav>
                <div className='wrap3'>
        <div className='form-wrapper'>
                <div>
                    
                      <Doughnut
                    data={status}
                    options={{
                        title:{
                            display:true,
                            text:'Average Rainfall per month',
                            fontSize:20
                        },
                        centerLabel:"560",
                        legend:{
                            display:true,
                            position:'right'
                        }
                    }}
                    />
                </div>
                </div>
                </div>
                </div>
            );
                }
            export default ClassReport;
