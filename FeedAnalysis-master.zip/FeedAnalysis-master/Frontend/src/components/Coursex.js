import React from 'react';
import img1 from "../assets/react.jpg";
import img2 from "../assets/node.png";
import img3 from "../assets/express.png";
import img5 from "../assets/python.jpeg";
import img4 from "../assets/c.jpeg";
import img6 from "../assets/java.jpg";
import img7 from "../assets/cloud.jpeg";
import img8 from "../assets/eth.png";
import img9 from "../assets/mongo.jpeg";
import {BrowserRouter as Router, Link, Switch, Route, Redirect, useHistory} from "react-router-dom";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";


const driver1 = ()=>{
    let x = document.querySelector(".nav-links");
    x.style.right = "-200px";
}


const driver2 = ()=>{
    var x = document.querySelector(".nav-links");
    x.style.right = "0";
}


const Coursex = () =>{
    return (
        <>

        <section className = "sub-header">
        <nav>
                <div className="pptx">
                    <h3>Educator</h3>
                </div>
                <div className="nav-links">
                <FontAwesomeIcon icon = "greater-than" className = "fa1" onClick = {driver1}/>
                <ul>
                
                    <li><Link to = "/home">Back</Link></li>
                    
                </ul>
                </div>
                <FontAwesomeIcon icon = "bars" className = "fa1" onClick = {driver2} />
            </nav>
        </section>
        <section className = "course">
            <h1>Our Courses</h1>
            <div className = "row">
                <div className = "course-col">
                <img src = {img1}></img>
                <h3>ReactJS</h3>
                </div>


                <div className = "course-col">
                <img src = {img2}></img>
                <h3>NodeJS</h3>
                </div>


                <div className = "course-col">
                <img src = {img3}></img>
                <h3>ExpressJS</h3>
                </div>
            </div>


            <div className = "row">
                <div className = "course-col">
                <img src = {img4}></img>
                <h3>C++</h3>
                </div>


                <div className = "course-col">
                <img src = {img5}></img>
                <h3>Python</h3>
                </div>


                <div className = "course-col">
                <img src = {img6}></img>
                <h3>Java</h3>
                </div>
            </div>


            <div className = "row">
                <div className = "course-col">
                <img src = {img7}></img>
                <h3>Cloud Computing</h3>
                </div>


                <div className = "course-col">
                <img src = {img8}></img>
                <h3>BlockChain</h3>
                </div>


                <div className = "course-col">
                <img src = {img9}></img>
                <h3>MongoDB</h3>
                </div>
            </div>
            

        </section>




        </>
    )
}

export default Coursex;