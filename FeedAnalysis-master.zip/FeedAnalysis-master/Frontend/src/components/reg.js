import React, {useState} from 'react';
const Reg = () =>{

    const [userRegister, setUserRegister] = useState({
        empid: "",
        empname: "",
        email: "",
        empdept: "",
        emppassword: ""
    });
    
    const [data, setData] = useState([]);

    const HandleDriver = (event) =>{
        const name =event.target.name;
        const value =event.target.value;
        setUserRegister({...userRegister, [name]: value})
    }

    const HandleSubmit = (event) =>{
        event.preventDefault();
        const newData = {...userRegister, id: new Date().getTime().toString()}
        setData([...data, newData]);
        setUserRegister({empname: "", email: "", empdept : "",empid: "", emppassword:""});
    }

    return (
        <>
        <h1>Educator Registration</h1>

        <form action = "" onSubmit = {HandleSubmit}>
            <div>
                <h2 classname ="title">Create Account</h2>
            </div>
            <div>
            <label htmlFor ="empid">Emp ID</label>
            <div>
                <input type ="text" autoComplete ="off" name ="empid" id="empid"
                value = {userRegister.empid} onChange = {HandleDriver}
                />
            </div>
            </div>



            <div>
                <div>
                <label htmlFor ="empname">Emp Name</label>
            </div>
            <div>
                <input type ="text" autoComplete ="off" name ="empname" id="empname"
                value = {userRegister.empname} onChange = {HandleDriver}
                />
            </div>

            </div>
            
            <div>
            <label htmlFor ="email">Emp Mail ID</label>
            <div>
            <input type ="text" autoComplete ="off" name ="empname" id="empname"
                value = {userRegister.email} onChange = {HandleDriver}
                /> 
            </div>
            </div>


            <div>
            <label htmlFor ="empdept">Emp Department</label>
            <div>
            <input type ="text" autoComplete ="off" name ="empdept" id="empdept"
                value = {userRegister.email} onChange = {HandleDriver}
                /> 
            </div>
            </div>



            <div>
            <label htmlFor ="emppassword">Emp Password</label>
            <div>
            <input type ="text" autoComplete ="off" name ="emppassword" id="emppassword"
                value = {userRegister.email} onChange = {HandleDriver}
                /> 
            </div>
            </div>

            <button type = "submit">Register</button>
        </form>
        </>
    )

}

export default Reg;
