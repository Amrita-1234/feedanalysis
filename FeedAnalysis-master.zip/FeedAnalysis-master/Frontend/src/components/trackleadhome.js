import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, useParams, Link, Switch, Route, Redirect, useHistory } from "react-router-dom";
import axios from "axios";

const Home = () => {
  const {Name} = useParams();
  let[department,setDepartment]=useState(null);
  let [responseData, setResponseData] = useState([]);
  useEffect(() => {
    axios.get('http://localhost:1050/getTrackLead').then((res) => {
      console.log(res.data)
      setResponseData(res.data)
    }).catch((err) => {
      console.log(err)
    })
  }, [])
  

  const history = useHistory();
  function logout() {
    localStorage.clear();
    history.push('/');
  }
  function pass(){
    history.push("/records/"+Name)
  }

  return (
    <div className="header3">
      <nav>
        <div className="nav-links">
          <ul>
          <li><Link onClick={logout}>Logout</Link></li>
          </ul>
        </div>
      </nav>
      <div className="text-box">
        <h1>
          {
            responseData.map((data) => data.Name=== Name?
              <h5 key={data.Name}>welcome {data.Name}
            </h5> : ""
            )
          }
        </h1>
        </div>
       
        <nav>
        <div className="nav-links">
          <ul>
          <li><Link onClick={pass}>Details</Link></li>
          </ul>
        </div>
      </nav>
        <div style={{flex:1,justifyContent:'flex-end'}}>
          
        </div>
        
      </div >
  );
};

export default Home
