import React, { Component } from "react";
import axios from "axios";

import { Redirect,Link} from "react-router-dom";

const url1="http://localhost:1050/getTrackLead";

class TrackLead extends Component {
  constructor(props) {
    super(props);
    this.state = {
      form: {
       
        Name: null,
        trackLeadEmailId:null,
        password: null
      },
      formErrors: {
        
        Name: "",
        trackLeadEmailId:"",
        password: ""
       
      },
      formValid:{
        Name: false,
        trackLeadEmailId:false,
        password: false,
        buttonActive:false
      },
      data:[],
      updateStatus:false,
      errorMessage:"",
      successMessage:""
    };
 }
  
  
storedetails=()=>{
  const {form}=this.state;
  this.state.data.map(item=>{
    console.log(item.Name)
    console.log(form.Name)
    console.log(item.trackLeadEmailId)
    console.log(form.trackLeadEmailId)
    console.log(item.password)
    console.log(form.password)
//this.setState({checkemail:item.email,checkdept:item.dept,checkpassword:item.password,})
    
if(form.Name===item.Name ){
if( form.trackLeadEmailId===item.trackLeadEmailId )
{
if( form.password===item.password)
  {
    this.setState({successMessage:"Successfully login"})
  this.setState({updateStatus:true})
  }
  else{
    console.log("error in password")
  }
}else
{
  console.log("error in mail")
}
}else
{
  console.log("error in Name")
}

  })
}

fetchdetails=()=>{
    this.setState({data:[]});
    axios.get(url1).then(response=>{
      this.setState({data:response.data,
    errorMessage:""});
  }).catch(error => {
    
      this.setState({ errorMessage: "Please start your express server" })
  });
  };
  componentDidMount(){
    this.fetchdetails();
    
  }
  
  handleSubmit = event => {
    event.preventDefault();
    
      console.log(`
      ---USER DETAILS---
      
      Email:${this.state.form.Name}
      Department:${this.state.form.trackLeadEmailId},
      Password:${this.state.form.password},
      `)
      this.storedetails();
  };

  handleChange = event => {
    const target = event.target;
    const value=target.value;
    const name=target.name;
    let formErrors = { ...this.state.formErrors };
    const {form}=this.state
    this.setState({form:{...form,[name]:value}})
    this.validateField(name, value);
  };

  validateField = (name, value) => {
    let fieldValidationErrors = this.state.formErrors;
    let formValid = this.state.formValid;

    switch (name) {
      case "trackLeadEmailId":
        const emailRegex = RegExp(
          /^[a-zA-Z0-9.!#$%&'*+/=?^_{|}~-]+@(infosys)+.(com)*$/
        );
        if (value === "") {
          fieldValidationErrors.trackLeadEmailId = "field required";
          formValid.trackLeadEmailId = false;
        } else if (!value.match(emailRegex)) {
          fieldValidationErrors.trackLeadEmailId = "Invalid email address";
          formValid.trackLeadEmailId = false;
        } else {
          fieldValidationErrors.trackLeadEmailId = "";
          formValid.trackLeadEmailId = true;
        }
        break;
        case "Name":
          if (value === "") {
            fieldValidationErrors.Name = "field required";
            formValid.Name = false;
          }else if (value.length<3) {
            fieldValidationErrors.Name = "min 3chars required";
            formValid.Name = false;
          } 
          else {
            fieldValidationErrors.Name = "";
            formValid.Name = true;
          }
  
          break;
      case "password":
        const passwordRegex=RegExp(
          /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,15}$/
          );
        if (value === "") {
          fieldValidationErrors.password = "field required";
          formValid.password = false;
        } 
        else if(!value.match(passwordRegex) ){
          fieldValidationErrors.password = "contains atleast 1 character,1 special character ,1 digit";
          formValid.password = false;
        }else {
          fieldValidationErrors.password = "";
          formValid.password = true;
        }
       
        break;
        
      default:
        break;
    }
    formValid.buttonActive=
    formValid.trackLeadEmailId&&formValid.Name&&formValid.password
    this.setState({ formErrors:fieldValidationErrors, formValid:formValid,successMessage:""})
    
  };
  
  render() {

    const { formErrors } = this.state
    let redirect=null;
        if(this.state.updateStatus ===true){
      console.log("record found successfully");
        redirect=<Redirect to="/records"></Redirect>
      }
      
    return (
      //<div className='checklogin'>
      <div className='wrapper'>
        <div className='form-wrapper'>
          <h1> Login to your Account</h1>
          <form onSubmit={this.handleSubmit}>

          <div className="dept">
              <label htmlFor="Name">Name </label>
              <input
                className={formErrors.Name.length > 0 ? "error" : null}
                type="text"
                name="Name"
                id="Name"
                placeholder="Name "
                value={this.state.form.Name}
                onChange={this.handleChange}

              />
              {
                formErrors.Name.length > 0 && (
                  <span className="text-danger">{formErrors.Name}</span>
                )
              }
            </div>
            <div className="email">
              <label htmlFor="trackLeadEmailId">Email </label>
              <input
                className={formErrors.trackLeadEmailId.length > 0 ? "error" : null}
                type="text"
                name="trackLeadEmailId"
                id="trackLeadEmailId"
                placeholder="email "
                value={this.state.form.trackLeadEmailId}
                onChange={this.handleChange}

              />
              {
                formErrors.trackLeadEmailId.length > 0 && (
                  <span className="text-danger">{formErrors.trackLeadEmailId}</span>
                )
              }
            </div>
            
            <div className="password">
              <label htmlFor="password">password </label>
              <input
                className={formErrors.password.length > 0 ? "error" : null}
                type="password"
                name="password"
                id="password"
                placeholder="password "
                value={this.state.form.password}
                onChange={this.handleChange}

              />
              {
                formErrors.password.length > 0 && (
                  <span className="text-danger">{formErrors.password}</span>
                )
              }
            </div>
            
            <div className="login">
            <button type="submit" className="btn btn-primary" disabled={!this.state.formValid.buttonActive} 
            >Login</button>
            
            </div>
            
          </form>
          <br />
          <span name="successMessage" className="text-success text-bold">
                  {this.state.successMessage}
                </span>
                <span name="errorMessage" className="text-danger text-bold">
                  {this.state.errorMessage}
                </span>
        </div>
        {redirect}
      </div>
      
     // </div>
    );
  }
}

export default TrackLead;
