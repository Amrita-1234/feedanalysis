import React, { useState ,useEffect} from 'react';
import { FaStar } from "react-icons/fa";
import { BrowserRouter as Router, useParams, Link, Switch, Route, Redirect, useHistory } from "react-router-dom";
import axios from "axios";
const Course = (props) => {
    let { id } = useParams();
    const [rate, setRate] = useState(null);
    const [hover, setHover] = useState(null);
    const [rate2, setRate2] = useState(null);
    const [hover2, setHover2] = useState(null);
    const [rate3, setRate3] = useState(null);
    const [hover3, setHover3] = useState(null);
    const [texter, setTexter] = useState(null);
    const onChange=(event)=>{
        setTexter(event.target.value);
    };

const handleSubmitClick=(e)=>{
    e.preventDefault();
    sendDetailsToServer()
}
    const sendDetailsToServer=()=>{
        const data={
            educatorId:id,
            rating1:rate,
            rating2:rate2,
            rating3:rate3,
            text:texter
    }
    
        axios.post('http://localhost:1050/courseFeedBack',data).then((res) => {
          console.log(res.data)
         console.log('sucess')
        }).catch((err) => {
          console.log(err)
        })
      }
    return (
        <div className="wrap">
        <div className="form-wrap">
        <div className="info">
            <h2>1. Topics</h2></div>
            {[...Array(5)].map((star, i) => {
                const ratingValue = i + 1;
                
                return (
                    <label>
                        
                        <input
                            type="radio"
                            name="rate"
                            value={ratingValue}
                            onClick={() => setRate(ratingValue)}


                        />
                        <FaStar
                            className="star"
                            color={ratingValue <= (hover || rate) ? "#ffc107" : "#e4e5e9"}
                            size={35}
                            onMouseEnter={() => setHover(ratingValue)}
                            onMouseLeave={() => setHover(null)}
                        />
                        </label>
                );
            })}
            <p>The rating is {rate}</p>
            <div className="info">
            <h2>2. Undertandable</h2></div>
            {[...Array(5)].map((star, j) => {
                const ratingValue2 = j + 1;

                return (
                    <label>
                        <input
                            type="radio"
                            name="rate2"
                            value={ratingValue2}
                            onClick={() => setRate2(ratingValue2)}


                        />
                        <FaStar
                            className="star"
                            color={ratingValue2 <= (hover2 || rate2) ? "#ffc107" : "#e4e5e9"}
                            size={35}
                            onMouseEnter={() => setHover2(ratingValue2)}
                            onMouseLeave={() => setHover2(null)}
                        />
                        </label>
                );
            })}
            <p>The rating is {rate2}</p>
            <div className="info"><h2>3. context</h2></div>
            {[...Array(5)].map((star, k) => {
                const ratingValue3 = k + 1;

                return (
                    <label>
                        <input
                            type="radio"
                            name="rate3"
                            value={ratingValue3}
                            onClick={() => setRate3(ratingValue3)}


                        />
                        <FaStar
                            className="star"
                            color={ratingValue3 <= (hover3 || rate3) ? "#ffc107" : "#e4e5e9"}
                            size={35}
                            onMouseEnter={() => setHover3(ratingValue3)}
                            onMouseLeave={() => setHover3(null)}
                        />
                        </label>
                );
            })}
            <p>The rating is {rate3}</p>

            <div className="info">
                <h2>4. Outcome</h2>
            </div>
            <textarea
            className="text"
            rows="4"
            cols="45"
            
                        name="texter"
                        value={texter}
                        placeholder="what's your experience?"
                        onChange={onChange}
                    />
            
            <p>The text is {texter}</p>
            <div className="feedback">
            <button
            type="submit"
            className="btn btn-primary"
            onClick={handleSubmitClick}>Submit</button></div>
        </div>
        </div> 
    );
}
export default Course;
