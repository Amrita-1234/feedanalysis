import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, useParams, Link, Switch, Route, Redirect, useHistory } from "react-router-dom";
import axios from "axios";
import Card from "react-bootstrap/Card"

const Details = () => {
  const { id,dept } = useParams();
  let [responseData, setResponseData] = useState([]);
  useEffect(() => {
    axios.get('http://localhost:1050/getBatchDetails').then((res) => {
      console.log(res.data)
      setResponseData(res.data)
    }).catch((err) => {
      console.log(err)
    })
  }, [])
  
  
 
  return (
    <div className="header3">
    <nav>
    <div className="nav-links2">
        <ul>
        <li><Link to={"/home/"+id+"/"+dept}>Back</Link></li>
        </ul>
      </div>
      <div className="nav-links3">
        <ul>
        <li>Assigned Details</li>
        <li></li>
        <li></li>
        </ul>
      </div>
      <div className="nav-links">
        <ul>
        <li><Link to={"/home/"+id+"/"+dept}>Home</Link></li>
        </ul>
      </div>
    </nav>
<div className='wrap3'>
<div >
        {responseData.length > 0 ? (
          
<div id="grid">
          <>
            {responseData.map(item => item.educatorId === id ? (
              <div >
              <table >
                <tr>
                <th>Assigned Date</th>
              <th>{new Date(new Date('2021-02-12T01:57:45.271Z').getTime()+Math.random()*(new Date('2021-04-28T01:57:45.271Z').getTime()-new Date('2021-02-12T01:57:45.271Z').getTime())).toISOString()}
              </th>
              </tr>
                <tr>
                  <th>BATCH</th>
                  
                  <th> <Link to={"/class/" + id+"/"+dept+"/"+item.batch}>{item.batch}</Link></th>  
                </tr>
                <tr>
                  <th>COURSE</th>
                  
                  <th ><Link to={"/course/" + id+"/"+dept+"/"+item.course}>{item.course}</Link></th>
                </tr>
                <tr>
                <th>STRENGTH</th>
                  <th>{Math.floor(Math.random() * 36) + 65}</th> 
                </tr>
                </table>
                </div>
            ):"")}
            </>
            <br></br>
            </div>  
           
            
          ) : <div className="text-center text-danger">Currently No Batch Details Are Assigned </div>
        }
</div>
        </div> 
        </div>


  );
};

export default Details
