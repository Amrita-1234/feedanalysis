import React from 'react'
import img1 from '../assets/index.jpeg';
import './Card.css';
function CardT(title, imageUrl, body){
    return (
        <div className = "card-container">
            <div className = "image-container">
                <img src = {imageUrl} alt= ''/>

            </div>
            <div className = "card-container">
            <div className="card-title">
                <h3>{body}</h3>
            </div>

            <div className="card-body">
                <p>{title}</p>
            </div>
            </div>

            

        </div>


            
    )
}

export default CardT;
