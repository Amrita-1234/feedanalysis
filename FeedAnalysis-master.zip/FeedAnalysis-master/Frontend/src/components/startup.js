import React from 'react';
import {BrowserRouter as Router, Link, Switch, Route, Redirect, useHistory} from "react-router-dom";
const Startup = () => {
    return (
        <div className="header">
            <nav>
                <div className="nav-links">
                <ul>
                    
                    <li><Link to = "/login">Login</Link></li>
                    <li><Link to = "/register">Sign up</Link></li>
                    <li><Link to = "#">About</Link></li>
                    <li><Link to = "#">Contact Us</Link></li>
                </ul>
                </div>
            </nav>
            <div className="text-box">
            <h1>Education is the movement from darkness to light</h1>
            
            </div>
        
        </div>
    );
};

export default Startup;