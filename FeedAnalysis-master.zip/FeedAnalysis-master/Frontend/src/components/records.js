import React, { Component } from 'react';
import { Redirect, Link } from "react-router-dom";
import axios from "axios";
import Card from "react-bootstrap/Card"
const url1 = "http://localhost:1050/";
class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data: [],
            id: "",
            updateStatus: false,
            errorMessage: "",
            successMessage: ""
        };
    }

    fetchdetails = () => {
        this.setState({ data: [] });
        axios.get(url1).then(response => {
            this.setState({
                data: response.data,
                errorMessage: ""
            });
            console.log(this.state.data);
        }).catch(error => {

            this.setState({ errorMessage: "Please start your express server" })
        });
    };
    componentDidMount() {
        this.fetchdetails();

    }
    handleClick=(ele) => {
        console.log("enterrd on click of button")
        this.setState({
            updateStatus: true,
            id: ele.educatorId
        })
    }
    displaytech = () => {
        let {  data} = this.state;
        return (
            data.map((item, index) => {
                return (
                    <div key={index}>
                        <button className="button" value={item} onClick={() => { this.handleClick(item)}}>{item.educatorId}</button>
                    </div>
                )
            }
            )
        )
    }
    render() {
        let { updateStatus, data, id } = this.state;
        if (updateStatus) {
            console.log(id);
            return (
                
                <Redirect to={"/response/" + id} />
            )
        }
        return (
            <div className="wrap">
                <div className="form-wrapper">
                    <h2 style={{ textAlign: "center" }}>Educators</h2>
                    <div id="grid">
                        {
                            data.length > 0 ? this.displaytech() : "no data was assigned"
                        }
                    </div>
                </div>
            </div>
        )
    }
}

export default Login