import React, { Component } from "react";
import axios from "axios";

import { Redirect,Link} from "react-router-dom";

const url1="http://localhost:1050/";
class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      form: {
       
        email: null,
        dept:null,
        password: null
      },
      formErrors: {
        
        email: "",
        dept:"",
        password: ""
       
      },
      formValid:{
        email: false,
        dept:false,
        password: false,
        buttonActive:false
      },
      data:[],
      checkemail:"",
      checkdept:"",
      checkpassword:"",
      id:"",
      updateStatus:false,
      errorMessage:"",
      successMessage:""
    };
  }
  
storedetails=()=>{
  const {form}=this.state;
  this.state.data.map(item=>{
//this.setState({checkemail:item.email,checkdept:item.dept,checkpassword:item.password,})

if(form.email===item.email && 
  form.dept===item.dept && form.password===item.password)
{
  if(form.dept==='ETA')
  {
  this.setState({updateStatus:true,id:item.educatorId})
  }
  else{
    console.log("Only ETA DEpartment employees can login")
  }
}else if(!(form.password===item.password)){
  this.setState({errorMessage:"Incorrect Password"})
}
  })
}

fetchdetails=()=>{
    this.setState({data:[]});
    axios.get(url1).then(response=>{
      this.setState({data:response.data,
    errorMessage:""});
  }).catch(error => {
    
      this.setState({ errorMessage: "Please start your express server" })
  });
  };
  componentDidMount(){
    this.fetchdetails();
    
  }
  
  handleSubmit = event => {
    event.preventDefault();
    
      console.log(`
      ---USER DETAILS---
      
      Email:${this.state.form.email}
      Department:${this.state.form.dept},
      Password:${this.state.form.password},
      `)
      this.storedetails();
  };

  handleChange = event => {
    const target = event.target;
    const value=target.value;
    const name=target.name;
    let formErrors = { ...this.state.formErrors };
    const {form}=this.state
    this.setState({form:{...form,[name]:value}})
    this.validateField(name, value);
  };

  validateField = (name, value) => {
    let fieldValidationErrors = this.state.formErrors;
    let formValid = this.state.formValid;

    switch (name) {
      case "email":
        const emailRegex = RegExp(
          /^[a-zA-Z0-9.!#$%&'*+/=?^_{|}~-]+@(infosys)+.(com)*$/
        );
        if (value === "") {
          fieldValidationErrors.email = "field required";
          formValid.email = false;
        } else if (!value.match(emailRegex)) {
          fieldValidationErrors.email = "Invalid email address";
          formValid.email = false;
        } else {
          fieldValidationErrors.email = "";
          formValid.email = true;
        }
        break;
        case "dept":
          if (value === "") {
            fieldValidationErrors.dept = "field required";
            formValid.dept = false;
          }else if (value.length<3) {
            fieldValidationErrors.dept = "min 3chars required";
            formValid.dept = false;
          } 
          else {
            fieldValidationErrors.dept = "";
            formValid.dept = true;
          }
  
          break;
      case "password":
        const passw=RegExp(
          /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{6,15}$/
          );
        if (value === "") {
          fieldValidationErrors.password = "field required";
          formValid.password = false;
        } 
        else if(!value.match(passw) ){
          fieldValidationErrors.password = "contains atleast 1 character,1 special character ,1 digit";
          formValid.password = false;
        }else {
          fieldValidationErrors.password = "";
          formValid.password = true;
        }
       
        break;
        
      default:
        break;
    }
    formValid.buttonActive=
    formValid.email&&formValid.dept&&formValid.password
    this.setState({ formErrors:fieldValidationErrors, formValid:formValid,successMessage:""})
    
  };
  
  render() {

    const { formErrors,text } = this.state
    let redirect=null;
        if(this.state.updateStatus ===true){
      console.log("record found successfully");
        redirect=<Redirect to={"/home/"+this.state.id} push></Redirect>
      }
      
    
    
    return (
      //<div className='checklogin'>
      <div className='wrapper'>
        <div className='form-wrapper'>
          <h1> Login to your Account</h1>
          <form onSubmit={this.handleSubmit}>

            
            <div className="email">
              <label htmlFor="email">Email </label>
              <input
                className={formErrors.email.length > 0 ? "error" : null}
                type="text"
                name="email"
                id="email"
                placeholder="email "
                value={this.state.form.email}
                onChange={this.handleChange}

              />
              {
                formErrors.email.length > 0 && (
                  <span className="text-danger">{formErrors.email}</span>
                )
              }
            </div>
            <div className="dept">
              <label htmlFor="dept">Department </label>
              <input
                className={formErrors.email.length > 0 ? "error" : null}
                type="text"
                name="dept"
                id="dept"
                placeholder="dept "
                value={this.state.form.dept}
                onChange={this.handleChange}

              />
              {
                formErrors.dept.length > 0 && (
                  <span className="text-danger">{formErrors.dept}</span>
                )
              }
            </div>
            <div className="password">
              <label htmlFor="password">password </label>
              <input
                className={formErrors.password.length > 0 ? "error" : null}
                type="password"
                name="password"
                id="password"
                placeholder="password "
                value={this.state.form.password}
                onChange={this.handleChange}

              />
              {
                formErrors.password.length > 0 && (
                  <span className="text-danger">{formErrors.password}</span>
                )
              }
            </div>
            
            <div className="login">
            <button type="submit" className="btn btn-primary" disabled={!this.state.formValid.buttonActive} 
            >Login</button>
            <small>If you don't have an account?<Link to ='/register'>Register</Link></small>
            </div>
            
          </form>
          <br />
          <span name="successMessage" className="text-success text-bold">
                  {this.state.successMessage}
                </span>
                <span name="errorMessage" className="text-danger text-bold">
                  {this.state.errorMessage}
                </span>
        </div>
        {redirect}
      </div>
      
     // </div>
    );
  }
}

export default Login;
