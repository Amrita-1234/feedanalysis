import React,{ Component } from "react";
import './App.css';
import {BrowserRouter as Router, Link, Switch, Route, Redirect} from "react-router-dom";
import Login from "./components/login";
import Register from "./components/register";
import Home from "./components/Home";
import Details from "./components/Details";
import Homepage1 from "./components/homepage1";
import Homepage2 from "./components/homepage2";
import Course from "./components/course";
import Class from "./components/class";
import Report from "./components/classreport";
import CourseReport from"./components/coursereport";
import tracklead from "./components/tracklead";
import records from "./components/records";
import finalreport from "./components/finalreport";
import trackleadhome from "./components/trackleadhome";
import 'react-notifications/lib/notifications.css';
import {NotificationContainer} from 'react-notifications';
class App extends Component{
    render(){
        return(
            <Router>
              <div>
          <Switch>
          <Route exact path="/login" component={Login} />
          <Route exact path="/register" component={Register} />
          <Route exact path="/home/:id/:dept" component={Home}/>
          <Route exact path="/trackleadhome/:trackLeadEmailId" component={trackleadhome}/>
          <Route exact path="/batchDetails/:id/:dept" component={Details}/>
          <Route exact path="/homepage1" component={Homepage1}/>
          <Route exact path="/homepage2" component={Homepage2}/>
          <Route exact path="/class/:id/:dept/:batch" component={Class}/>
          <Route exact path="/course/:id/:dept/:course" component={Course}/>
          <Route exact path="/classreport/:id/:dept/:batch" component={Report}/>
          <Route exact path="/coursereport/:id/:dept/:course" component={CourseReport}/>
          <Route exact path="/trackleadlogin" component={tracklead}/>
          <Route exact path="/records/:trackLeadEmailId" component={records}/>
          <Route exact path="/finalreport/:trackLeadEmailId/:id" component={finalreport}/>
            <Route  path="/" component={Homepage1}/>
            
          </Switch>
          </div>
          <NotificationContainer />
            </Router>
        );
    }
}
export default App;
