import React from "react";
//import { shallow } from "enzyme";
import renderer from "react-test-renderer";
import App from "./App";
import {storedetails,fetchdetails} from "./components/login";
import { submitregister} from "./components/register";
import { sendDetailsToServer} from "./components/class";
import { handleSubmitClick} from "./components/course";
import {useEffect}  from "./components/classreport";
import {useEffect1}  from "./components/coursereport";
describe("App Snapshot", () => {
  test("renders", () => {
  });
});
describe("App Snapshot", () => {
  test("renders", () => {
    const component = renderer.create(<App />);
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();
  });
});
describe("Login StoreDetails ", () => {
  test("renders", () => {
    const component = renderer.create(<storedetails/>);
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();
  });
});
describe("Login FetchDetails ", () => {
  test("renders", () => {
    const component = renderer.create(<fetchdetails/>);
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();
  });
});

describe("Register ", () => {
  test("renders", () => {
    const component = renderer.create(<submitregister/>);
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();
  });
});

describe("class", () => {
  test("renders", () => {
    const component = renderer.create(<sendDetailsToServer/>);
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();
  });
});
describe("Course", () => {
  test("renders", () => {
    const component = renderer.create(<handleSubmitClick/>);
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();
  });
});
describe("Class Report", () => {
  test("renders", () => {
    const component = renderer.create(<useEffect/>);
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();
  });
});
describe("Class Report", () => {
  test("renders", () => {
    const component = renderer.create(<useEffect1/>);
    let tree = component.toJSON();
    expect(tree).toMatchSnapshot();
  });
});
